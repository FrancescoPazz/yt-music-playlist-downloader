"""QuickJS-ng executable for ytmpd on Android, shipped as libqjs.so."""
